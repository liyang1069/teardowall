package com.teardowall.task;

public class JokeGetter {
	
	public void run(){
		
	}
}
