package com.teardowall.models;

public class GroupsSites extends BaseModel {
	private String webGroupId;
	private String webSiteId;
	
	public String getWebGroupId() {
		return webGroupId;
	}
	public void setWebGroupId(String webGroupId) {
		this.webGroupId = webGroupId;
	}
	public String getWebSiteId() {
		return webSiteId;
	}
	public void setWebSiteId(String webSiteId) {
		this.webSiteId = webSiteId;
	}
}
